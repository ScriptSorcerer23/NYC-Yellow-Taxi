# NYC-Yellow-Taxi
End-to-end data science pipeline on the NYC Yellow Taxi dataset using PySpark, MLflow, and AWS S3, with deployment via FastAPI and Docker.

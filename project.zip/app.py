import streamlit as st
import numpy as np
import pickle
import pandas as pd
from PIL import Image

# 🔧 MUST BE FIRST
st.set_page_config(page_title="NYC Taxi Predictor", layout="wide")

# =======================
# 📌 Custom CSS Styling
# =======================
st.markdown("""
    <style>
        label, input, .stNumberInput input,
        .markdown-text-container p, .markdown-text-container span {
            font-size: 1.2rem !important;
        }

        h1 { font-size: 2.5rem !important; }
        h2 { font-size: 1.8rem !important; }

        body { line-height: 1.6; }

        #predict-button button {
            background-color: #FFD700; /* Changed to yellow */
            color: black; /* Changed to black for better contrast */
            font-weight: bold;
            border-radius: 10px;
            font-size: 1.2rem;
            height: 3rem;
            width: 100%;
            transition: 0.3s ease;
        }

        #predict-button button:hover {
            background-color: #FFC800; /* Darker yellow */
            transform: scale(1.03);
        }

        #summary-button button {
            background-color: #1E90FF; /* Changed to blue */
            color: white;
            font-weight: bold;
            border-radius: 10px;
            font-size: 1.2rem;
            height: 3rem;
            width: 100%;
            transition: 0.3s ease;
        }

        #summary-button button:hover {
            background-color: #187BCD; /* Darker blue */
            transform: scale(1.03);
        }

        #visualize-button button {
            background-color: #32CD32; /* Changed to green */
            color: white;
            font-weight: bold;
            border-radius: 10px;
            font-size: 1.2rem;
            height: 3rem;
            width: 100%;
            transition: 0.3s ease;
        }

        #visualize-button button:hover {
            background-color: #28A428; /* Darker green */
            transform: scale(1.03);
        }
    </style>
""", unsafe_allow_html=True)

# =======================
# 📦 Load Models
# =======================
with open("logistic_regression_model.pkl", "rb") as f:
    lr_model = pickle.load(f)
with open("decision_tree_model.pkl", "rb") as f:
    dt_model = pickle.load(f)
with open("kmeans_model.pkl", "rb") as f:
    kmeans_model = pickle.load(f)

# =======================
# 📊 Sidebar Visual Insights
# =======================
st.sidebar.markdown('<div style="text-align:center; font-weight:bold; margin-bottom:10px;">Model Comparison Overview</div>', unsafe_allow_html=True)
st.sidebar.image("model_comparison.png", use_container_width=True)
st.sidebar.markdown("<br>", unsafe_allow_html=True)

st.sidebar.markdown('<div style="text-align:center; font-weight:bold; margin-bottom:10px;">What influences tips the most?</div>', unsafe_allow_html=True)
st.sidebar.image("features_tips.png", use_container_width=True)
st.sidebar.markdown("<br>", unsafe_allow_html=True)

st.sidebar.markdown('<div style="text-align:center; font-weight:bold; margin-bottom:10px;">Most people travel alone!</div>', unsafe_allow_html=True)
st.sidebar.image("passenger.png", use_container_width=True)
st.sidebar.markdown("<br>", unsafe_allow_html=True)

st.sidebar.markdown('<div style="text-align:center; font-weight:bold; margin-bottom:10px;">Yellow cab demands in NYC rise between 1 PM and 7 PM, peaking around 6 PM</div>', unsafe_allow_html=True)
st.sidebar.image("hours_demand.png", use_container_width=True)

# =======================
# 🧠 Main App Content
# =======================
st.markdown("""
    <h1 style='text-align: center; font-size: 2.8rem;'>🚖 NYC Taxi ML Prediction App</h1>
    <p style='text-align: left; font-size: 1.2rem; margin-top: 1.5rem;'>
        Enter ride details and predict the <strong>payment type</strong> and <strong>cluster group</strong>.<br>
        Also explore model behavior and clusters below.
    </p>
""", unsafe_allow_html=True)

# 📥 Inputs
passenger_count = st.number_input("👥 Passenger Count", min_value=1, max_value=6, value=1)
trip_distance = st.number_input("📏 Trip Distance (miles)", min_value=0.0, value=2.5, step=0.1)
fare_amount = st.number_input("💵 Fare Amount ($)", min_value=0.0, value=10.0, step=0.5)

# 🧮 Input features
default_values = [0.5, 0.5, 2.0, 0.0, 0.3, 13.3, 2.5]
input_df = np.array([[passenger_count, trip_distance, fare_amount, *default_values]])

# 🗺️ Mapping
payment_mapping = {
    1: "Credit card", 2: "Cash", 3: "No charge",
    4: "Dispute", 5: "Unknown", 6: "Voided trip"
}
cluster_descriptions = {
    0: "Most common trips – short distance, moderate fare, mostly card payments",
    1: "Sparse cluster",
    2: "Sparse cluster",
    3: "Outlier cluster – extremely long trip durations (~1400 minutes!)",
    4: "High-value trips – long distance, higher fares, more tolls and tips"
}

# =======================
# 🔘 Custom Button Triggers
# =======================
# =======================
# 🔘 Custom Button Triggers
# =======================
if "trigger_predict" not in st.session_state:
    st.session_state.trigger_predict = False
if "trigger_summary" not in st.session_state:
    st.session_state.trigger_summary = False
if "trigger_visual" not in st.session_state:
    st.session_state.trigger_visual = False

col1, col2, col3 = st.columns([1, 1, 1])

with col1:
    predict_button = st.button("🚀 Predict", key="predict")
    if predict_button:
        st.session_state.trigger_predict = True
    st.markdown("""
        <style>
            div[data-testid="stButton"] > button:first-child {
                background-color: #32CD32;
                color: black;
            }
            div[data-testid="stButton"] > button:first-child:hover {
                background-color: #1E90FF;
            }
        </style>
    """, unsafe_allow_html=True)

with col2:
    summary_button = st.button("📑 See Cluster Summary", key="summary")
    if summary_button:
        st.session_state.trigger_summary = True
    st.markdown("""
        <style>
            div[data-testid="stButton"] > button:nth-child(2) {
                background-color: #1E90FF;
                color: white;
            }
            div[data-testid="stButton"] > button:nth-child(2):hover {
                background-color: #187BCD;
            }
        </style>
    """, unsafe_allow_html=True)

with col3:
    visual_button = st.button("📊 Visualize Clusters", key="visual")
    if visual_button:
        st.session_state.trigger_visual = True
    st.markdown("""
        <style>
            div[data-testid="stButton"] > button:nth-child(3) {
                background-color: #32CD32;
                color: white;
            }
            div[data-testid="stButton"] > button:nth-child(3):hover {
                background-color: #28A428;
            }
        </style>
    """, unsafe_allow_html=True)
# =======================
# ✅ Button Logic
# =======================
if st.session_state.trigger_predict:
    st.session_state.trigger_predict = False
    lr_pred = lr_model.predict(input_df)[0]
    dt_pred = dt_model.predict(input_df)[0]
    cluster_pred = kmeans_model.predict(input_df)[0]

    lr_proba = lr_model.predict_proba(input_df)[0]
    dt_proba = dt_model.predict_proba(input_df)[0]

    st.subheader("🔍 Prediction Results")
    st.markdown(f"**Logistic Regression Prediction:** `{lr_pred}` – {payment_mapping.get(lr_pred, 'Unknown')}")
    st.progress(float(max(lr_proba)))

    st.markdown(f"**Decision Tree Prediction:** `{dt_pred}` – {payment_mapping.get(dt_pred, 'Unknown')}")
    st.progress(float(max(dt_proba)))

    st.markdown(f"**KMeans Cluster:** `{cluster_pred}` – {cluster_descriptions.get(cluster_pred, 'Unknown cluster')}")

if st.session_state.trigger_summary:
    st.session_state.trigger_summary = False
    st.subheader("📘 Cluster Summaries")
    for cid, summary in cluster_descriptions.items():
        st.markdown(f"<p><strong>Cluster {cid}</strong>: {summary}</p>", unsafe_allow_html=True)

if st.session_state.trigger_visual:
    st.session_state.trigger_visual = False
    st.subheader("Cluster Visualization")
    cluster_img = Image.open("cluster_plot.png")
    st.image(cluster_img, caption="KMeans Clustering on NYC Taxi Data", use_container_width=True)

# Footer space
st.markdown("<div style='height: 80px;'></div>", unsafe_allow_html=True)
